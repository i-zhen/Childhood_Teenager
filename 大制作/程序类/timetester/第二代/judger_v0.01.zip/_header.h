#include<iostream>
#include<cstring>
#include<string>
#include<cstdlib>
#include<iomanip>
#include<stdlib.h>
#include<fstream>

#ifndef _LINUX_Head
#define _LINUX_Head

#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<sys/resource.h>
#include<sys/times.h>
#include <sys/ptrace.h>
#include <asm/ptrace-abi.h>

#else

#endif
